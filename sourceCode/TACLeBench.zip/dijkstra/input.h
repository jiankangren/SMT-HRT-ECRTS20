#ifndef INPUT_H
#define INPUT_H

#define NUM_NODES 100

extern unsigned char dijkstra_AdjMatrix[NUM_NODES][NUM_NODES];

#endif  /* INPUT_H */
