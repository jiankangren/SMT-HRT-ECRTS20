#ifndef AMMUNITION_STDLIB_H
#define AMMUNITION_STDLIB_H

int ammunition_atoi ( const char *str );

#endif
