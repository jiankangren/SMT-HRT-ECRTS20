#ifndef AMMUNITION_STDIO_H
#define AMMUNITION_STDIO_H

int ammunition_sprintf_d( char *s, int number );

int ammunition_sprintf_u( char *s, unsigned int number );

#endif
